package baickotlin.com.hellokotlin

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.TypedValue
import android.widget.TextView

class SecondKotlinActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second_kotlin)
        val tvScecondActivity = findViewById(R.id.tvScecondActivity) as TextView
        tvScecondActivity.setTextColor(Color.parseColor("#FF4081"))
        tvScecondActivity.setTypeface(null, Typeface.BOLD)
        tvScecondActivity.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20F)
    }
}
