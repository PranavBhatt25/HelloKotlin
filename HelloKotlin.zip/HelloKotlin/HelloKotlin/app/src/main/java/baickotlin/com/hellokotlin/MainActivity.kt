package baickotlin.com.hellokotlin

import Utils.toast
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.view.Menu
import android.view.MenuItem

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val toolbar = findViewById(R.id.toolbar) as Toolbar
        setSupportActionBar(toolbar)

        val fab = findViewById(R.id.fab) as FloatingActionButton

        //  METHOD (2) CONVERTED TO LAMBDA START NEW ACTIVITY
        fab.setOnClickListener {
            view ->
            toast("Button clicked")
            val i = Intent(getApplicationContext() as Context, SecondKotlinActivity::class.java)
            intent.putExtra("key", "")
            startActivity(i)
        }

        //  SIMPLE METHOD (1) TO START NEW ACTIVITY
//        fab.setOnClickListener(object : View.OnClickListener {
//            override fun onClick(view: View): Unit {
//                val i = Intent(getApplicationContext() as Context, SecondKotlinActivity::class.java)
//                intent.putExtra("key", "")
//                startActivity(i)
//            }
//        })
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        val id = item.itemId

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            toast("Menu Settings clicked")
            return true
        }

        return super.onOptionsItemSelected(item)
    }
}
